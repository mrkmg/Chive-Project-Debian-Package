<script type="text/javascript">
$(document).ready(function() {
	if(location.href.indexOf('#') == -1)
	{
		chive.goto('tables');
	}
});
</script>