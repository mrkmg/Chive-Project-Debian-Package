Chive
=====

Chive is a modern Open-Source MySQL Data Management tool. With it's fast and elaborate user interface it is getting very popular especially by web engineers. Chive was created because of an disaffection with existing tools. They usually were hard to handle and very time-consuming while the daily use of an web engineer.

The first version of chive was shipped in Oktober 2009. Since that, the project is moving forward in various directions:

* Improving features to provide even better user experience
* Implementing missing functionality
* Fixing Bugs and improving stability

Installation on Linux
=====
If you are using Linux, there is a very simple way to install Chive. 
Just run the following command in your terminal window to download and extract Chive:

    wget -O - http://www.chive-project.com/Download/Redirect|tar -xzp

This command will download the latest version of Chive and extract it into a directory named "chive". 
All relevant file/directory privileges are stored in the tarball.


Author
=====
Chive is sponsored by Fusonic (http://www.fusonic.net)


Licence
=====
Chive is released under the terms of the GNU General Public License v3.
